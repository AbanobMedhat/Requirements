<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_database";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
unset($_SESSION["username"]);
  if (isset($_SESSION["username"]) && $_SESSION["username"] == "admin") {
    header("Location: upload.php");
    exit;}

     elseif (isset($_SESSION["username"]) && $_SESSION["username"] == "test") {
    header("Location: dummy_content.php");
    exit;}
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if username and password are correct
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // User is authenticated, set session variables
        $user = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_type'] = $user['user_type'];

        // Redirect based on user type
          
        if ($user['user_type'] == 'admin') {


            header("Location: upload.php");
        } else {
            header("Location: dummy_content.php");
        }
    } else {
        // Invalid username or password
        echo "Invalid username or password";
    }
}


?>
<html>
<head>
  <title>Upload File</title>
  
   
  <link rel="stylesheet" type="text/css" href="style.css">
  
</head>
<body>
<form action="" method="post" class="form-upload">
    <label for="username">Username</label>
    <input type="text" name="username" required>
    <label for="password">Password</label>
    <input type="password" name="password" required>
    <!--Don't forget to change the credentials of test:test user-->
    <input type="submit" name="submit" value="Login">
</form>
</body>
</html>