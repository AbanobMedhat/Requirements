<?php
  session_start();

  if (!isset($_SESSION["username"]) || $_SESSION["username"] != "admin") {
    header("Location: login.php");
    exit;
  }
  if (isset($_POST['submit'])) {
    // Check if file was uploaded
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        // Check if file size is within allowed limit
        if ($_FILES['file']['size'] <= 10000000) {
            // Get file extension
            $extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
            // Generate unique filename
            $filename = uniqid() . "." . $extension;
            // Set destination folder
            $destination = __DIR__ . "/upload/" . $filename;
            // Move file to destination folder
            if (move_uploaded_file($_FILES['file']['tmp_name'], $destination)) {
                 echo '<div id="message_success">File uploaded successfully</div>';

            } else {
                echo "Failed to upload file";

            }
        } else {
            echo "File size exceeded limit";
        }
    } else {
        echo "File not uploaded";
    }
}


?>

<!DOCTYPE html>
<html>
<head>
  <title>Upload File</title>
  

  <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
  <div class="Admin_Flag">
    <p>Hello Admin, U arrived in the right place. Thus, this is your flag</p>
    <p>CTF_FLAG{MIU_Adm!n_U$3r}</p>
  
    <div class="container">
    <h1>Upload File</h1>
   
<form action="" method="post" enctype="multipart/form-data">
    <label for="file">File:</label>
    <input type="file" name="file" required>
    <input type="submit" name="submit" value="Upload">
</form>
  </div>
</body>
<script>
  setTimeout(function() {
    var message = document.getElementById("message_success");
    message.style.display = "none";
  }, 5000);
</script>
</html>
