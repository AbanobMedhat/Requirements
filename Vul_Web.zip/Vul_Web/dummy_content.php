<?php
  session_start();

  if (!isset($_SESSION["username"]) || $_SESSION["username"] != "test") {
    header("Location: login.php");
    exit;
  }
  ?>

<!DOCTYPE html>
<html>
<head>
  <title>Course Catalog</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <h1>Course Catalog</h1>
  <table>
    <tr>
      <th>Code</th>
      <th>Title</th>
      <th>Description</th>
      <th>Semester</th>
    </tr>
    <tr>
      <td>CSC101</td>
      <td>Introduction to Computer Science</td>
      <td>This course provides an overview of the field of computer science and covers basic concepts such as algorithms, programming, and data structures.</td>
      <td>Fall</td>
    </tr>
    <tr>
      <td>CSC102</td>
      <td>Data Structures and Algorithms</td>
      <td>This course teaches students how to use advanced data structures such as trees, graphs, and hash tables to solve complex problems.</td>
      <td>Spring</td>
    </tr>
    <tr>
      <td>CSC103</td>
      <td>Object-Oriented Programming</td>
      <td>This course introduces students to the concepts of object-oriented programming and covers topics such as classes, objects, inheritance, and polymorphism.</td>
      <td>Fall</td>
    </tr>
  </table>

<!-- Add a comment form -->
<div class="add-comment-section">
  <h2>Add a comment</h2>
  <form action="dummy_content.php" method="post">
    

    <label for="comment">Comment:</label>
    <textarea id="comment" name="comment"></textarea>

    <input type="submit" value="Submit">
  </form>
</div>

<?php
  // Check if the form was submitted
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Connect to the database
    $conn = mysqli_connect("localhost", "root", "", "my_database");

    // Check the connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }

    // Escape the input to prevent SQL injection
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    // Insert the comment into the comments table
    $sql = "INSERT INTO comments (comment)
            VALUES ('$comment')";
    if (mysqli_query($conn, $sql)) {
      echo "<p>Comment added successfully!</p>";
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the connection
    mysqli_close($conn);
  }
?>

<!-- Display all comments -->
<div class="comments-section">
  <h2>Comments</h2>
  <?php
    // Connect to the database
    $conn = mysqli_connect("localhost", "root", "", "my_database");

    // Check the connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve all comments from the comments table
    $sql = "SELECT * FROM comments ";
    $result = mysqli_query($conn, $sql);

    // Display each comment
    if (mysqli_num_rows($result) > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='comment'>";
        echo "<p>" . $row['comment'] . "</p>";
        echo "</div>";
      }
    } else {
      echo "<p>No comments yet. Be the first to comment!</p>";
    }

    // Close the connection
    mysqli_close($conn);
  ?>
</div>



</body>
</html>
